<?PHP
ob_start();
@session_start();


//==================================================
// صفحة الإتصال بقاعدة البيانات 
	include('include/config.php');
//==================================================


//التحقق من صحة الدخول للمستخدم
//echo $_SESSION["user_name"];
 If(!isset($_SESSION['user_name']) OR !isset($_COOKIE['user_name']))//التحقق ما إذا تم تسجيل الدخول أو  لا
 { 
exit("<META HTTP-EQUIV='refresh' CONTENT='0 URL=login.php'>");//الذهاب الي صفحة  تسجيل الدخول  مباشرتا أذا لم  يكن مسجلاً 
 }
 else
 {
	include('include/1top.php');

$user_fullname=$_SESSION["user_name"];
$part_no=$_SESSION['part_no'];
$user_id=$_SESSION['user_id'];



if(isset($_GET["action"])) $action=$_GET["action"] ; else  $action=" " ; 
 

if ($action=='edit_user')
{ 
$query=("SELECT * FROM users WHERE user_id = $user_id");
$resq=mysql_query($query);

$num_results = mysql_num_rows($resq)  or die ("لا يوجد مستخدمين ");
$i=0;
while($i<$num_results)
{
$row=mysql_fetch_array($resq);
 
		echo "
		<br>
		<form action='main.php?action=update_user' method='post' enctype='multipart/form-data'>
		<table id='rounded-corner' Profit' class='auto-style3' style=' font-size: large; height: 85px;  margin:0px auto; ' align='center' dir='rtl'>
		<caption class='auto-styl' style='height: 40px; font-size: x-large; border: 5; border-color: #9845C8; background-color: #43001e; color: #FFFFFF' >
	الرجاء قم بإدخال البيانات المطلوبة   
		</caption>
		<tr>
			<td style='width: 192px; height: 58px;'>إسم المستخدم الذي يدخل به الموقع</td>
			<td style='height: 58px'> 
			<input name='user_name' type='text' value='$row[user_name]' style='width: 300px; height: 40px; amimuth: center; border-style: solid; border-top-style: double; border-width: thick; border-color: #43001e; font-weight: bold; font-style: italic; font-size: large; text-align: center;  color: #43001e'>

			<br><br></td>
		</tr>
		<tr>
			<td style='width: 192px; height: 58px;'>كلمة السر </td>
			<td style='height: 58px'> 
			<input name='password' type='text' value='$row[password]'  style='width: 300px; height: 40px; amimuth: center; border-style: solid; border-top-style: double; border-width: thick; border-color: #43001e; font-weight: bold; font-style: italic; font-size: large; text-align: center;  color: #43001e'>

			<br><br></td>
		</tr>
		
		<tr>
			<td colspan='2'>
			<input dir='rtl' name='Submit' style='width: 159px; border-color: #6600CC; height: 44px; background-color: #43001e; color: #FFFFFF; font-size: x-large;' type='submit' value='تعديل' />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<input dir='rtl' name='Reset1' style='width: 125px; height: 43px; border-color: #6600CC; color: #FFFFFF; background-color: #43001e; font-size: x-large;' type='reset' value='مسح البيانات' /></td>
		</tr>
	</table>
</form>

<br><br><br>
       ";
$i++;
}
}
else if ($action=="update_user")
{
if($_POST['Submit']) {

$user_name=$_POST['user_name'];
$password=$_POST['password'];

//echo "$users_image";
//echo  "$mitem_no + $mitem_no jhjsdhjdsj" ;
if ( empty($user_name) ||  empty($password) ) 
{echo  " الرجاء قم بتعبئة جميع الحقول للرجوع الى الخلف  <a href='javascript:history.back(1)'> إضغط هنا  </a> <br><br>" ;}

else
{

//echo "$users_name + $users_num";
$query="UPDATE `users` SET 
`user_name` = '$user_name ',
`password` = '$password'
WHERE  `user_id` = '$user_id'" ;
$resq=mysql_query($query);
$message_text="لقد تمت عملية التعديل  <br><br>";
echo "<META HTTP-EQUIV='refresh' CONTENT='2 URL=main.php'> ";

if ($resq === true) 
{$mesnum=1; 
include('include/message.php');
 }
else
{$mesnum=2; 
$message_text="لم تتم العملية بنجاح للرجوع الى الخلف <a href='javascript:history.back(1)'> إضغط هنا  </a> <br><br>";
include('include/message.php');
 }
 }
 }
 
else
echo "لزر المضغوط للرجوع الى الخلف إضغط هنا <a href='javascript:history.back(1)'> إضغط هنا  </a> <br><br>" ;

}
else  
{

	$query=("SELECT * FROM users WHERE user_id = $user_id");
$resq=mysql_query($query);

$num_results = mysql_num_rows($resq)  or die ("لا يوجد مستخدمين ");
$i=0;
while($i<$num_results)
{
$row=mysql_fetch_array($resq);
 
		echo "
		<br>
		
		<table id='rounded-corner' Profit' class='auto-style3' style=' font-size: x-large; height: 85px;  margin:0px auto; ' align='center' dir='rtl'>
		<caption class='auto-styl' style='height: 40px; font-size: x-large; border: 5; border-color: #9845C8; background-color: #43001e; color: #FFFFFF' >
	مرحبا  بك  في  موقعنا  هذه هي بياناتك الخاصة المخزنة في موقعنا 
		</caption>
	
		<tr>
			<td style='width: 192px; height: 58px;'>الأســــــم كاملاً</td>
			<td style='height: 58px'> 
			'$row[ful_name]' 
			<br></td>
		</tr>
		<tr>
			<td style='width: 192px; height: 58px;'>القسم الخاص بك هو </td>
			<td style='height: 58px'> 
	
			";
			
			if($row['part_no']==0)
			echo " عـــــام ";
			else
			{
				//تعبئة  إسماء  الأقسام  الى  الموقع
			$query=("select part_no,part_name  from partments where part_no= $row[part_no]");
            $resq2=mysql_query($query);
            if (  $resq2 >0)
			{
			 $row2=mysql_fetch_array($resq2);
			 echo " $row2[part_name]  ";
			}
			}
			echo "  </td>	</tr>
		<tr>
			<td colspan='2' style='width: 192px; height: 58px;'>
			لتغير  إسم  المستخدم  وكلمة  السر  في  موقعنا 
			<a href='main.php?action=edit_user'> إضغط هنا </a>
			<br><br></td>
		</tr>
		
		
	
	</table>

<br><br><br>
       ";
$i++;
}
}		
}