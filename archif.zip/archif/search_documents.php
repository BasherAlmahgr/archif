<?PHP
ob_start();
@session_start();


//التحقق من صحة الدخول للمستخدم
//echo $_SESSION["user_name"];
 If(!isset($_SESSION['user_name']) OR !isset($_COOKIE['user_name']))//التحقق ما إذا تم تسجيل الدخول أو  لا
 { 
exit("<META HTTP-EQUIV='refresh' CONTENT='0 URL=login.php'>");//الذهاب الي صفحة  تسجيل الدخول  مباشرتا أذا لم  يكن مسجلاً 
 }
 else
 {
 
 
 
$user_fullname=$_SESSION["user_name"];
$part_no=$_SESSION['part_no'];
$user_id=$_SESSION['user_id'];

include('include/1top.php');

//==================================================
	// استدعاء بيانات ملف اعداد الاتصال بقاعدة البيانات
	include('include/config.php');
	//==================================================
	if(isset($_GET["action"])) $action=$_GET["action"] ; else  $action=" " ; 
 if(isset($_GET["dn"])) $doc_no=$_GET["dn"] ; 
   
 if ($action=="search")
{
echo "<br />
<form action='search_documents.php?action=search_do' method='post'  enctype='multipart/form-data'>
	<table align='center' cellpadding='10' cellspacing='10' class='auto-style3'  dir='rtl' style='width: 70%; text-align: center; border-color: #43001e ; color: #43001e;  margin:0px auto; font-size: large; font:12pt PT Bold Heading, Geneva, sans-serif;' >
		<caption  style='height: 40px; font-size: large; border: 5; border-color: #9845C8; background-color: #43001e; color: #FFFFFF' >
		الرجاء قم بإدخال البيانات المطلوبة لإتمام عملية البحث 
		</caption>
		
		<tr>
			<td style='width: 192px; height: 40px;'> عنوان الوثيقة </td>
			<td style='height: 40px'> 
			<input name='doc_title'  style='width: 400px; height: 40px; azimuth: center; border-style: solid; border-top-style: double; border-width: thick; border-color: #43001e; font-weight: bold; font-style: italic; font-size: large; text-align: center;  color: #43001e'>

			</td>
		</tr>
		<tr>
			<td style='width: 192px; height: 40px;'> رقم  ملف الإرشيف </td>
			<td style='height: 40px'> 
			<input name='file_no'  style='width: 400px; height: 40px; azimuth: center; border-style: solid; border-top-style: double; border-width: thick; border-color: #43001e; font-weight: bold; font-style: italic; font-size: large; text-align: center;  color: #43001e'>

			</td>
		</tr>
		<tr>
			<td style='width: 192px; height: 40px;'>معلومات عن الوثيقة </td>
			<td style='height: 40px'> 
			<input name='doc_info'  style='width: 400px; height: 40px; azimuth: center; border-style: solid; border-top-style: double; border-width: thick; border-color: #43001e; font-weight: bold; font-style: italic; font-size: large; text-align: center;  color: #43001e'> 

			</td>
		</tr>
			
		<tr>
		
			<td colspan='2'>
			 <br><br>
<p align='center'><input type='radio' value='AND' checked name='tipe_search'> بحث كل البيانات     
<input type='radio' value='OR' name='tipe_search'> بحث احد البيانات <br>		 <br>
			<input dir='rtl' name='Submit' style='width: 159px; border-color: #43001e; height: 40px; background-color: #43001e; color: #FFFFFF; font-size: large;' type='submit' value='بـــــحــث' />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<input dir='rtl' name='Reset1' style='width: 125px; height: 40px; border-color: #43001e; color: #FFFFFF; background-color: #43001e; font-size: large;' type='reset' value='مسح البيانات' /></td>
		</tr>
	</table>
</form>


     
";

}

else if ($action=="search_do")
{
if($_POST['Submit']) {

$doc_title=trim($_POST["doc_title"]);
$doc_info=$_POST["doc_info"]; 
$file_no=$_POST["file_no"]; 
$tipe_search =$_POST["tipe_search"];

$number =0;


		// التاكد انه ادخل حقل واحد على الاقل للبحث
		if($doc_title=="" AND
		   $doc_info=="" AND
		   $file_no=="" 
		  )
		{
			echo "<br><br><p dir='rtl'>لم تقم بادخال بيانات للبحث</p>";
			echo "<p dir='rtl'>
			<br><br>
			<a href='javascript:history.back(1)'>
			        اضغط هنا للمحاوله مره اخرى
			        </a></p><br><br>";
		}
		else
		{
			$v1=0;$v2=0;$v3=0;
			if($doc_title<>"")
			{
				$doc_title = "doc_title like '%$doc_title%'";
				$v1 = 1;
			}
			if($doc_info<>"")
			{
				$doc_info = "doc_info like '%$doc_info%'";
				$v2 = 1;
			}
			if($file_no<>"")
			{
				$file_no = "file_no like '%$file_no%'";
				$v3 = 1;
			}
			$tipe_search1 ="";
			$tipe_search2 ="";
			$result_document  ="";
			 
			if(($v1 == 1 and $v2 == 1) OR
			   ($v1 == 1 and $v3 == 1) )  {$tipe_search1 = $tipe_search;}
			if(($v2 == 1 and $v3 == 1) )  {$tipe_search2 = $tipe_search;}
			
			
			// $tipe_search  =  OR او AND
			if ($part_no==0)
			$result = mysql_query("SELECT * FROM  documents WHERE
										 $doc_title   $tipe_search1 
										 $doc_info    $tipe_search2 
										 $file_no  
										 order by doc_no") or die(mysql_error()); 	
			else
			$result = mysql_query("SELECT * FROM  documents WHERE
										 $doc_title   $tipe_search1 
										 $doc_info    $tipe_search2 
										 $file_no 
										and part_no = $part_no
										 order by doc_no") or die(mysql_error()); 	
										 
			$result_num = mysql_num_rows($result);
			if($result_num==0)
			{
				echo "<center><font style='font:14pt PT Bold Heading, Geneva, sans-serif;'> 
				<br><br><p dir='rtl'>لا يوجد نتيجة للبحث</p>";
			    echo "<p dir='rtl'><br><br><a href='javascript:history.back(1)'>
			          
			          اضغط هنا للمحاوله مره اخرى
			          </a></p><br><br> </font> ";
			}
			else
			{
			$number =0;
				for ($i=0; $i<$result_num; $i++)
				{
						$result_info       = mysql_fetch_array($result);
						$doc_no        = $result_info['doc_no'];
						$doc_title = $result_info['doc_title' ];
						$doc_info = $result_info['doc_info' ];
						// اسم الطلاب الناتج
						$number ++;
						$result_document   .= "$number - <a href='search_documents.php?action=document_prview&dn=$doc_no'> $doc_title  ( $doc_info ) </a><br><br>";			
				};
			}

		// طبع نتيجة البحث
	}		echo "<center><font style='font:14pt PT Bold Heading, Geneva, sans-serif;'> <br><br> لقد تم  إيجاد  عدد ( $number  )  وثيقة مخزنة في قاعدةة البيانات <br><br><p dir='rtl'>$result_document</p> </font>";
}


}

else if ($action=="document_prview")
{
$query=("SELECT * FROM documents  WHERE doc_no = $doc_no");
$resq=mysql_query($query);

$num_results = mysql_num_rows($resq)  or die ("لا توجد   وثائق مخزنة في  قاعدة  البيانات   ");
$i=0;
while($i<$num_results)
{
$row=mysql_fetch_array($resq);
 
		
echo "<br />
	<br>
		
		<table id='rounded-corner' Profit' class='auto-style3' style=' font-size: x-large; height: 85px;  margin:0px auto; font:14pt PT Bold Heading, Geneva, sans-serif; ' align='center' dir='rtl'>
		<caption class='auto-styl' style='height: 40px; font-size: x-large; border: 5; border-color: #9845C8; background-color: #43001e; color: #FFFFFF' >
	عرض تفاصيل  الوثيقة 
		</caption>
	
		<tr>
			<td style='width: 192px; height: 58px;'> عنوان  الوثيقة </td>
			<td style='height: 58px'> 
			'$row[doc_title]' 
			<br></td>
		</tr>
		
		<tr>
			<td style='width: 192px; height: 58px;'> رقم ملف الأرشيف  </td>
			<td style='height: 58px'> 
			$row[file_no] 
			<br></td>
		</tr>
		<tr>
			<td style='width: 192px; height: 58px;'> معلومات  عن  الوثيقة  </td>
			<td style='height: 58px'> 
			$row[doc_info]
			<br></td>
		</tr>
	<tr>
			<td style='width: 192px; height: 58px;'> صورة  الوثيقة   </td>
			<td style='height: 58px'> 
			<img src='$row[doc_image]' alt='' title='$row[doc_title]'width='250' height='200'  border='0' /> 
			<br></td>
		</tr>
	</table>

<br><br><br>
<br><br><br>
     
";
$i++;
}
}

else 
{



}

}
?>
