﻿<?php
ob_start();
@session_start();


//التحقق من صحة الدخول للمستخدم
//echo $_SESSION["user_name"];
 If(!isset($_SESSION['user_name']) OR !isset($_COOKIE['user_name']))//التحقق ما إذا تم تسجيل الدخول أو  لا
 { 
exit("<META HTTP-EQUIV='refresh' CONTENT='0 URL=login.php'>");//الذهاب الي صفحة  تسجيل الدخول  مباشرتا أذا لم  يكن مسجلاً 
 }
 else
 {
 
 
	include('include/1top.php');

 //==================================================
	// استدعاء بيانات ملف اعداد الاتصال بقاعدة البيانات
	include('include/config.php');
	//==================================================
	if(isset($_GET["action"])) $action=$_GET["action"] ; else  $action=" " ; 
 if(isset($_GET["ui"])) $users_num=$_GET["ui"] ; 
 if(isset($_GET["mai"])) $mitem_no=$_GET["mai"] ; 
   
    
$title= "سجل المستخدمين";



echo  "<center>";
		
 if ($action=='users_display' ||$action== "delete_user")
{

 if ($action== "delete_user")
{


$query="DELETE FROM `users` WHERE `user_id` = '$users_num'"  ;
$resq=mysql_query($query);
if ($resq==true)
{
$message_text="لقد تم حذف المستخدم بنجاح <br><br>";
$mesnum=1; 
include('include/message.php');
}
else
echo "لم تتم عملية الحذف";
 echo "<META HTTP-EQUIV='refresh' CONTENT='2 URL=users_home.php?action=users_display'> ";
}



// استخراج بيانات المحتويات الفرعية الموجوده
		
		$query=("SELECT * FROM  users ");
			$resq=mysql_query($query);
			$num_results = mysql_num_rows($resq) ;
		if($num_results==0)
		{
			echo "<p dir='rtl'>لا يوجد مستخدمين مخزنين في قاعدة البيانات</p>
			      <p dir='rtl'><a href='users_home.php?action=add_user_form'>للبدء في اضافة مستخدمين اضغط هنا !</a></p>";	
		}
		else
		{
		
		echo " 
       <center>
<br>
 <div id='table-scroll'  style=' overflow:auto; '>
				<table id='rounded-corner' Profit' class='auto-style3' style=' font-size: large; height: 85px;  margin:0px auto; ' align='center' dir='ltr'>
<caption class='auto-styl' style='height: 40px; font-size:large; border: 5; border-color: #9845C8; background-color: #43001e; color: #FFFFFF' >
	هؤلاء هم جميع المستخدمين في الموقع
		</caption>   
      <thead>
    	<tr>
		  
           <th scope='col' class='rounded'> نوع المستخدم </th>
		   <th scope='col' class='rounded' >كلمة السر</th>
		   <th scope='col' class='rounded'  >إسم المستخدم للدخول</th>
		     <th scope='col' class='rounded'  >القسم</th>
           <th scope='col' class='rounded'  > إسم المستخدم  كاملا</th>
           <th scope='col'>تعديل</th>
           <th scope='col' class='rounded'>حذف</th>
        </tr>
    </thead>
         <tbody> "; 
			$i=0; 
           while($i<$num_results)
			{
			
			$row=mysql_fetch_array($resq);
			
			//التحقق من نوعية المستخدم
			$ch=$row['ch'];
			if($ch==1)
			$check='مدير';
			else
			$check='عادي';
			
			echo"<tr>	
			<td >$check </td>
				<td >$row[password]</td>
				<td >$row[user_name]  </td>";
			if($row['part_no']==0)
			echo "<td >عــام</td>";
			else
			{
				//تعبئة  إسماء  الأقسام  الى  الموقع
			$query=("select part_no,part_name  from partments where part_no= $row[part_no]");
            $resq2=mysql_query($query);
            if (  $resq2 >0)
			{
			 $row2=mysql_fetch_array($resq2);
			 echo "<td >$row2[part_name]  </td>";
			}
			}
			  
			
				echo "<td >$row[ful_name]</td>
				
				<td><a href='users_home.php?action=edit_user&ui=$row[user_id]'>
				<img src='images/edit.png' alt='' title='تعديل' border='0' /></a></td>
				<td>
				<a onClick=\"javascript: return confirm('هل أنت متأكد من حذف المستخدم /$row[ful_name] ');\" href='users_home.php?action=delete_user&ui=$row[user_id]' class='ask'>
				<img src='images/del.gif' alt='' title='حذف' border='0' /></a></td>
				</tr>   ";
				$i++;
		    }
      echo "  
	  <tr>
        	<td colspan='6' class='rounded-foot-left'><em> <p dir='rtl'>
			<a href='users_home.php?action=add_user_form'>لإضافة مستخدم جديد إضغط هنا </a>
			</p></em></td>
        	<td class='rounded-foot-right'>&nbsp;</td>
			</tr>
			</tbody>
			</table> 
			</font>
			</div>
			";
		
		}


}

else if ($action=='edit_user')
{ 

$query=("SELECT * FROM users WHERE user_id = $users_num");
$resq=mysql_query($query);

$num_results = mysql_num_rows($resq)  or die ("لا يوجد مستخدمين ");
$i=0;
while($i<$num_results)
{
$row=mysql_fetch_array($resq);
 
		echo "
		<br>
		<form action='users_home.php?action=update_user&ui=$users_num' method='post' enctype='multipart/form-data'>
		<table id='rounded-corner' Profit' class='auto-style3' style=' font-size: large; height: 85px;  margin:0px auto; ' align='center' dir='rtl'>
		<caption class='auto-styl' style='height: 40px; font-size: x-large; border: 5; border-color: #9845C8; background-color: #43001e; color: #FFFFFF' >
	الرجاء قم بإدخال البيانات المطلوبة   
		</caption>
	
		<tr>
			<td style='width: 192px; height: 58px;'>إسم المستخدم كاملاً</td>
			<td style='height: 58px'> 
			<input name='ful_name' value='$row[ful_name]' type='text'  style='width: 300px; height: 40px; amimuth: center; border-style: solid; border-top-style: double; border-width: thick; border-color: #43001e; font-weight: bold; font-style: italic; font-size: large; text-align: center;  color: #43001e'>

			<br><br></td>
		</tr>
		<tr>
			<td style='width: 192px; height: 58px;'>القسم الخاص به</td>
			<td style='height: 58px'> 
		<select class='auto-style2' dir='rtl' name='part_no' style='width: 250px; height: 40px; azimuth: center; border-style: solid; border-top-style: double; border-width: thick; border-color: #43001e; font-weight: bold; font-style: italic; font-size: large; text-align: center;  color: #43001e'>
        ";
			
			if($row['part_no']==0)
			echo "<option value='0'>عام</option>";
			else
			{
				//تعبئة  إسماء  الأقسام  الى  الموقع
			$query=("select part_no,part_name  from partments where part_no= $row[part_no]");
            $resq2=mysql_query($query);
            if (  $resq2 >0)
			{
			 $row2=mysql_fetch_array($resq2);
			 echo "<option value='$row2[part_no]'>$row2[part_name] </option>";
			}
			}
			echo "  <option value='0'>عام</option> ";
			//تعبئة  إسماء  الأقسام  الى  الموقع
			$query=("select part_no,part_name  from partments");
            $resq=mysql_query($query);
            $num_results2 = mysql_num_rows($resq)  or die (" لا يوجد أقسام مخزنة في قاعدة البيانات");
			for($i=1;$i<=$num_results2;$i++)
			{$row2=mysql_fetch_array($resq);
			 echo "<option value='$row2[part_no]'>$row2[part_name] </option> ";
			}
			echo "
		</select>	</tr>
		<tr>
			<td style='width: 192px; height: 58px;'>إسم المستخدم الذي يدخل به الموقع</td>
			<td style='height: 58px'> 
			<input name='user_name' type='text' value='$row[user_name]' style='width: 300px; height: 40px; amimuth: center; border-style: solid; border-top-style: double; border-width: thick; border-color: #43001e; font-weight: bold; font-style: italic; font-size: large; text-align: center;  color: #43001e'>

			<br><br></td>
		</tr>
		<tr>
			<td style='width: 192px; height: 58px;'>كلمة السر </td>
			<td style='height: 58px'> 
			<input name='password' type='text' value='$row[password]'  style='width: 300px; height: 40px; amimuth: center; border-style: solid; border-top-style: double; border-width: thick; border-color: #43001e; font-weight: bold; font-style: italic; font-size: large; text-align: center;  color: #43001e'>

			<br><br></td>
		</tr>
		
		<tr>
			<td colspan='2'>
			<input dir='rtl' name='Submit' style='width: 159px; border-color: #6600CC; height: 44px; background-color: #43001e; color: #FFFFFF; font-size: x-large;' type='submit' value='تعديل' />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<input dir='rtl' name='Reset1' style='width: 125px; height: 43px; border-color: #6600CC; color: #FFFFFF; background-color: #43001e; font-size: x-large;' type='reset' value='مسح البيانات' /></td>
		</tr>
	</table>
</form>

<br><br><br>
       ";
$i++;
}
}

else if ($action=="update_user" || $action=="add_user")
{
if($_POST['Submit']) {

$ful_name=trim($_POST['ful_name']);
$user_name=$_POST['user_name'];
$part_no=$_POST['part_no'];
$password=$_POST['password'];
if  ($part_no == '0')
$check=1;
else 
$check=0;

//echo "$users_image";
//echo  "$mitem_no + $mitem_no jhjsdhjdsj" ;
if (empty($ful_name)  ||empty($user_name) ||  empty($password) ) 
{echo  " الرجاء قم بتعبئة جميع الحقول للرجوع الى الخلف  <a href='javascript:history.back(1)'> إضغط هنا  </a> <br><br>" ;}

else
{

if ($action=="update_user")
{

//echo "$users_name + $users_num";
$query="UPDATE `users` SET 
`ful_name` = '$ful_name ',
`part_no` = '$part_no ',
`user_name` = '$user_name ',
`password` = '$password',
`ch` = '$check'
WHERE  `user_id` = '$users_num'" ;
$resq=mysql_query($query);
$message_text="لقد تمت عملية التعديل  <br><br>";
echo "<META HTTP-EQUIV='refresh' CONTENT='2 URL=users_home.php?action=users_display'> ";

}
else
{
$query="INSERT INTO `users` (
`ful_name` ,
`part_no` ,
`user_name` ,
`password` ,
`ch` 
)
VALUES (
 '$ful_name' ,
 '$part_no' ,
 '$user_name' ,
 '$password',
 '$check' 
 )";
$resq=mysql_query($query);
$message_text="لقد تم إضافة   الى المستخدم  بنجاح  <br><br>";
echo "<META HTTP-EQUIV='refresh' CONTENT='2 URL=users_home.php?action=users_display'> ";


}
if ($resq === true) 
{$mesnum=1; 
include('include/message.php');
 }
else
{$mesnum=2; 
$message_text="لم تتم العملية بنجاح للرجوع الى الخلف <a href='javascript:history.back(1)'> إضغط هنا  </a> <br><br>";
include('include/message.php');
 }
 }
 }
 
else
echo "لزر المضغوط للرجوع الى الخلف إضغط هنا <a href='javascript:history.back(1)'> إضغط هنا  </a> <br><br>" ;

}
else if ($action=="add_user_form")
{


		echo "
		<br>
		<form action='users_home.php?action=add_user' method='post' enctype='multipart/form-data'>
		<table id='rounded-corner' Profit' class='auto-style3' style=' font-size: large; height: 85px;  margin:0px auto; ' align='center' dir='rtl'>
		<caption class='auto-styl' style='height: 40px; font-size: x-large; border: 5; border-color: #9845C8; background-color: #43001e; color: #FFFFFF' >
	الرجاء قم بإدخال البيانات المطلوبة   
		</caption>
		
			<tr>
			<td style='width: 192px; height: 58px;'>إسم المستخدم كاملاً</td>
			<td style='height: 58px'> 
			<input name='ful_name' type='text'  style='width: 250px; height: 40px; amimuth: center; border-style: solid; border-top-style: double; border-width: thick; border-color: #43001e; font-weight: bold; font-style: italic; font-size: large; text-align: center;  color: #43001e'>

			<br><br></td>
		</tr>
		<tr>
			<td style='width: 192px; height: 58px;'>القسم الخاص به</td>
			<td style='height: 58px'> 
		<select class='auto-style2' dir='rtl' name='part_no' style='width: 250px; height: 40px; azimuth: center; border-style: solid; border-top-style: double; border-width: thick; border-color: #43001e; font-weight: bold; font-style: italic; font-size: large; text-align: center;  color: #43001e'>
             <option value=''>إختر  القسم المنتمي اليه</option> <option value='0'>عام</option> ";
			//تعبئة  إسماء  الأقسام  الى  الموقع
			$query=("select part_no,part_name  from partments");
            $resq=mysql_query($query);
            $num_results2 = mysql_num_rows($resq)  or die (" لا يوجد أقسام مخزنة في قاعدة البيانات");
			for($i=1;$i<=$num_results2;$i++)
			{$row2=mysql_fetch_array($resq);
			 echo "<option value='$row2[part_no]'>$row2[part_name] </option> ";
			}
			echo "
		</select>	 
			 <br></td>
		</tr>
		<tr>
			<td style='width: 192px; height: 58px;'>إسم المستخدم الذي يدخل به الموقع</td>
			<td style='height: 58px'> 
			<input name='user_name' type='text'  style='width: 250px; height: 40px; amimuth: center; border-style: solid; border-top-style: double; border-width: thick; border-color: #43001e; font-weight: bold; font-style: italic; font-size: large; text-align: center;  color: #43001e'>

			<br><br></td>
		</tr>
		<tr>
			<td style='width: 192px; height: 58px;'>كلمة السر </td>
			<td style='height: 58px'> 
			<input name='password' type='text'  style='width: 250px; height: 40px; amimuth: center; border-style: solid; border-top-style: double; border-width: thick; border-color: #43001e; font-weight: bold; font-style: italic; font-size: large; text-align: center;  color: #43001e'>

			<br><br></td>
		</tr>
		<tr>
			<td colspan='2'>
			<input dir='rtl' name='Submit' style='width: 159px; border-color: #43001e; height: 40px; background-color: #43001e; color: #FFFFFF; font-size: x-large;' type='submit' value='حــــفظ' />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<input dir='rtl' name='Reset1' style='width: 125px; height: 40px; border-color: #43001e; color: #FFFFFF; background-color: #43001e; font-size: x-large;' type='reset' value='مسح البيانات' /></td>
		</tr>
		</table>
		</form>

		<br><br><br>
     
		";
		
			
			}
else 
{

//الإنتقال الى لوحة التحكم الرئيسية 
 echo "<META HTTP-EQUIV='refresh' CONTENT='0 URL=control_panel.php'> ";
 

	
}
}

?>