<?PHP
ob_start();
@session_start();


//التحقق من صحة الدخول للمستخدم
//echo $_SESSION["user_name"];
 If(!isset($_SESSION['user_name']) OR !isset($_COOKIE['user_name']))//التحقق ما إذا تم تسجيل الدخول أو  لا
 { 
exit("<META HTTP-EQUIV='refresh' CONTENT='0 URL=login.php'>");//الذهاب الي صفحة  تسجيل الدخول  مباشرتا أذا لم  يكن مسجلاً 
 }
 else
 {
 
 
//==================================================
	// استدعاء بيانات ملف اعداد الاتصال بقاعدة البيانات
	include('include/config.php');
	//==================================================
include('include/1top.php');
	if(isset($_GET["action"])) $action=$_GET["action"] ; else  $action=" " ; 
 if(isset($_GET["pn"])) $part_no=$_GET["pn"] ; 
  
echo "<center >";

if ($action=='partment_display'  || $action== "partment_delete" || $action=="add_partment" || $action=="update_partment")
{
//كود  حذف قسم 
if ($action== "partment_delete")
{

$query="DELETE FROM `partments` WHERE `part_no` = '$part_no'"  ;
$resq=mysql_query($query);
if ($resq==true)
{
$message_text="لقد تم حذف القسم بنجاح  <br><br>";
$mesnum=1; 
include('include/message.php');
echo "<META HTTP-EQUIV='refresh' CONTENT='2 URL=partments.php?action=partment_display'> ";
}
else
{
$message_text= "لم تتم عملية حذف  هذا القسم ...هناك خطاء <br><br>";
$mesnum=2; 
include('include/message.php');
}
}
// كود إضافة  قسم  جديد  
if  ($action=="add_partment" || $action=="update_partment") 
{

if($_POST['Submit']) {

$part_name=trim($_POST["part_name"]);

// التاكد من تسجيله لبقية البيانات الضروريه 
			if($part_name =="")
			{
				$mesnum=2; 
			$message_text= "     لم تدخل اسم القسم       ";
		 	include('include/message.php');
			echo "<META HTTP-EQUIV='refresh' CONTENT='2 URL=partments.php?action=partment_display'> ";

			}
			else 
			{
			
		
if ($action=="update_partment")
{  

//echo "$student_num + $student_num";
$query="UPDATE `partments` SET 
`part_name` = '$part_name'	
WHERE  `part_no` = '$part_no'" ;
$resq=mysql_query($query);
 
$message_text="لقد تمت عملية التعديل بنجاح  <br><br>";
echo "<META HTTP-EQUIV='refresh' CONTENT='2 URL=partments.php?action=partment_display'> ";

}
else
{

 
 
 
$query="INSERT INTO `partments` 
(`part_name` )
VALUES ('$part_name')";
$resq=mysql_query($query);

$message_text="لقد تم إضافة  القسم  $part_name  بنجاح   <br>";
echo "<META HTTP-EQUIV='refresh' CONTENT='2 URL=partments.php?action=partment_display'> ";
}
if ($resq === true) 
{$mesnum=1; 
include('include/message.php');
 }
else
{$mesnum=2; 
$message_text="لم تتم العملية بنجاح للرجوع الى الخلف <a href='javascript:history.back(1)'> إضغط هنا  </a> <br><br>";
include('include/message.php');
 }
 }
 
}
}
//بدء  كود  واجهة  الإقسام 
echo "
		<!--كود تعديل التوقيع بالاخفاء والاظهار-->
<div align='center'>
<script> 
function showHide(what){
a=what.getElementsByTagName('div')[0];
if(a.style.display=='none'){
a.style.display='block';
}else{
a.style.display='none';
}}
</script>
<input type='button' onclick='showHide(this.parentNode)' value='إضــــافة قسم جديد ' style='width: 159px; border-color: #FF3300; height: 40px; background-color: #43001e; color: #FFFFFF; font-size: large;'>
<div style='display:none'>
		<fieldset width=100% dir='rtl'>
		<legend>
		إضافة قسم 
		</legend>
		
<form action='partments.php?action=add_partment' method='post'  enctype='multipart/form-data'>
	<table align='center' cellpadding='10' cellspacing='10' class='auto-style3'  dir='rtl' style='width: 100%; text-align: center; border-color: #6600CC ; color: #43001e;  margin:0px auto; font-size: large' >
		
		<tr>
			<td style='width:150px; height: 58px;'>إسم  القسم </td>
			<td style='height: 58px'> 
			<input name='part_name'  style='width: 350px; height: 40px; azimuth: center; border-style: solid; border-top-style: double; border-width: thick; border-color: #43001e; font-weight: bold;  font-size: large; text-align: center;  color: #43001e'>
</td><td style='height: 58px'> 
	<input dir='rtl' name='Submit' style='width: 159px; border-color: #FF3300; height: 40px; background-color: #43001e; color: #FFFFFF; font-size: large;' type='submit' value='إضــــــافة' />
		
			</td>
		</tr>
	
		
	</table>
</form>

		</fieldset>
</div>
	
				
	
";
$query=("select *  from partments ORDER BY `part_name` ASC  ");
$resq=mysql_query($query);
$num_results = mysql_num_rows($resq);
if ($num_results==0)
{
echo  "  <br /> <br /><br /> <br /> لا  يوجد أقسام مخزنة  في قاعدة البيانات
 <br /> <br />"; 
}
else 
{
	

$i=0;
echo " <center>
<br><br>
 <div id='table-scroll'  style=' overflow:auto; '>
				<table id='rounded-corner' Profit' class='auto-style3' style='width:100%; height: 85px;  margin:0px auto; ' align='center' dir='ltr'>
<caption class='auto-styl' style='height: 30px; font-size: large; border: 5; border-color: #9845C8; background-color: #43001e; color: #FFFFFF' >
		الأقسام  المتوفرة  حالياً في  موقعنا 
		</caption>   
   <thead>
    	<tr> 
			<th scope='col' class='rounded'  style='width: 80%'>إسم  القسم  </th>
			
            <th scope='col'>تعديل</th>
            <th scope='col' class='rounded-q4'>حذف</th>
        </tr>
    </thead>
    <tbody> "; 
	
while($i<$num_results)
{
$row=mysql_fetch_array($resq);

	
    	echo "<tr>
        	<td style='width: 10%'>$row[part_name]</td>
			

            <td><a href='partments.php?action=edit_partment&pn=$row[part_no]'>
			<img src='images/edit.png' alt='' title='تعديل' border='0' /></a></td>
           
		   <td> <a onClick=\"javascript: return confirm('هل أنت متأكد من حذف القسم   /  $row[part_name] ');\" href='partments.php?action=partment_delete&pn=$row[part_no]' class='ask'>
			<img src='images/del.gif' alt='' title='حذف' border='0' /></a></td>
        </tr>   ";
        $i++;
		}
      echo "  
    </tbody>
</table> 
</div></center>
";
}
}
else  if ($action == "edit_partment" ) 
{

$query=("SELECT * FROM partments  WHERE part_no = $part_no");
$resq=mysql_query($query);

$num_results = mysql_num_rows($resq)  or die ("لا توجد أقسام مخزنة في  قاعدة  البيانات   ");
$i=0;
while($i<$num_results)
{
$row=mysql_fetch_array($resq);
 
		
echo "<br />
<form action='partments.php?action=update_partment&pn=$row[part_no]' method='post'  enctype='multipart/form-data'>
	<table align='center' cellpadding='10' cellspacing='10' class='auto-style3'  dir='rtl' style='width: 70%; text-align: center; border-color: #FF3300 ; color: #43001e; margin:0px auto; font-size: x-large' >
		<caption  style='height: 30px; font-size:  large; border: 5; border-color: #9845C8; background-color: #43001e; color: #FFFFFF' >
		الرجاء قم بإدخال البيانات المطلوبة لإتمام عملية التعديل
		</caption>
		<tr>
			<td style='width: 192px; height: 20px;'> </td>
			<td style='height: 20px'>
			</td>
		</tr>
		<tr>
			<td style='width: 192px; height: 58px;'>إسم  القسم </td>
			<td style='height: 58px'> 
			<input name='part_name'  value = '$row[part_name]'  style='width: 400px; height: 40px; azimuth: center; border-style: solid; border-top-style: double; border-width: thick; border-color: #43001e; font-weight: bold; font-style: italic; font-size: large; text-align: center;  color: #43001e'>

			</td>
		</tr>
		<tr>
			<td colspan='2'>
			<input dir='rtl' name='Submit' style='width: 159px; border-color: #FF3300; height: 40px; background-color: #43001e; color: #FFFFFF; font-size:large;' type='submit' value='تعــــديـــل' />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<input dir='rtl' name='Reset1' style='width: 125px; height: 40px; border-color: #FF3300; color: #FFFFFF; background-color: #43001e; font-size: large;' type='reset' value='مسح البيانات' /></td>
		</tr>
	</table>
</form>

<br><br><br>
     
";
$i++;
}


}


echo "</center >";
}
?>