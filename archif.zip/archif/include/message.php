
<ul class="states">
<?php
if ($mesnum==1)	
	{
	echo "<li class='succes'><span class='successICO'>Success</span>$message_text</li>";
    }
	else if ($mesnum==2)
	{
	echo "<li class='error'><span class='errorICO'>error</span>$message_text</li> ";
	}
    else 	if ($mesnum==3)			
	{
	echo "<li class='warning'><span class='warningICO'>warning</span>$message_text</li>";
	}
	?>
	</ul>