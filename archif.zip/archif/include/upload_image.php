<?php
Function upload($image,$tmpimage,$path)
{

/*
كود رفع الصورة  الى  مجلد وتخزين المسار في قاعدة البيانات 
by ENG/Ishmael Ali AL_SheHali 
*/

//هذا هو إسم الصورة مع الإمتداد   $_FILES['file1']['name'] ;
//$image=$_FILES['file1']['name'] ;
//$tmpimage=$_FILES['file1']['tmp_name'] ;
//كود تجريد إسم الصورة لأخذالإمتداد فقط
$explode = explode('.', $image);

//أخذ أمتداد الصورة 
$ext = $explode[count($explode) - 1];

//كود التحقق من أذا كانت امتدادات الصورة هي المطلوبة أو  لا  
if($ext != 'png' && $ext != 'jpg' && $ext != 'jpeg' && $ext != 'gif')
{
echo "الرجاء قم بإختيار الصورة ذو  أحدى الإمتدادات التالية ( PNG - jpg -jpeg - gif ) للرجوع الى الخلف  <a href='javascript:history.back(1)'> إضغط هنا  </a> <br><br>";
exit();
}

if  ( is_dir($path)== false) // التحقق من أن المسار منشاء أو لا أذا لم يكن منشاء سيتم إنشائه
if (mkdir($path))   // التحقق من أنه تم الإنشاء بنجاح
{echo '<br> لقد تم إنشاء المجلد بنجاح <br>'; }

//كود رفع الصورة الى المسار المطلوب
if(is_uploaded_file($tmpimage))
{
$result = move_uploaded_file($tmpimage, $path.  basename($image));

echo $result === true ? "<br> لقد تم رفع الصورة بنجاح <br>"  :  '<br> لم يستطع رفع الصورة بسبب وجود  مشكلة <br>';
}
else
{
echo '<br> لم تتم عملية رفع الصورة <br>';
}

//كود عرض الصورة
$pri="$path$image";

	
	
return  $pri;
}

?>