﻿<?php
ob_start();
@session_start();

//التحقق من صحة الدخول للمستخدم
//echo $_SESSION["user_name"];
 If(!isset($_SESSION['user_name']) OR !isset($_COOKIE['user_name']))//التحقق ما إذا تم تسجيل الدخول أو  لا
 { 
exit("<META HTTP-EQUIV='refresh' CONTENT='0 URL=login.php'>");//الذهاب الي صفحة  تسجيل الدخول  مباشرتا أذا لم  يكن مسجلاً 
 }
 
$user_fullname=$_SESSION["user_name"];
$part_no=$_SESSION['part_no'];
$user_id=$_SESSION['user_id'];


 ?>
 <html xmlns="#">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/style.css"/>
<title>موقع أرشيف </title>
</head>

<body>