﻿<?php
ob_start();
@session_start();

//التحقق من صحة الدخول للمستخدم
//echo $_SESSION["user_name"];
 If(!isset($_SESSION['user_name']) OR !isset($_COOKIE['user_name']))//التحقق ما إذا تم تسجيل الدخول أو  لا
 { 
exit("<META HTTP-EQUIV='refresh' CONTENT='0 URL=login.php'>");//الذهاب الي صفحة  تسجيل الدخول  مباشرتا أذا لم  يكن مسجلاً 
 }
 
$user_fullname=$_SESSION["user_name"];
$part_no=$_SESSION['part_no'];
$user_id=$_SESSION['user_id'];


 ?>
 <html xmlns="#">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/style.css"/>
<title>موقع أرشيف </title>
</head>

<body>
<div id="header">
<div id="header-mid">

<ul id="navbar">
<li><a href="main.php" target="bottom">الرئيسيه</a></li>

<li><a href="documents.php?action=add_document_form" target="bottom">إضافة  وثيقة  </a></li>
<li><a href="documents.php?action=document_display" target="bottom" >الارشيف </a></li>
<li><a href="search_documents.php?action=search" target="bottom">البحث عن وثيقة </a></li>
<?php 
if ($part_no == 0 ) 
{ 
?>
<li><a href="users_home.php?action=users_display" target="bottom" >المستخدمين </a></li>
<li><a href="partments.php?action=partment_display" target="bottom">الأقسام</a></li>
<li><a href="del_document.php?action=document_display" target="bottom">سجل  المتابعة </a></li>
<?php  } ?> 
<li><a href="login.php?action=logout"  >تسجيل  الخروج </a></li>
</ul>


<div id="share">
<a href="#"><img src="images/fb.png" alt="facebook"  /></a>
<a href="#"><img src="images/tw.png" alt="twitter"  /></a>
</div>

</div><!--end header mid-->
</div><!--end header-->
<div id="content">

	
<table width=100% border=0>
<tr ><td width=80%>


	<iframe src="main.php" name="bottom" width="100%" height="540" frameborder="2" SCROLLING="yes" noresize ></iframe>
		

 </td ><td width=40%>
  <div  class="sidebar">


 <center>	<img src='images/wel.png' width='150px' height='150px' border=2> </center>
<h2>Control Panel لوحة التحكم</h2><!--first post-->
<ul class="side">
<li><a href="main.php" target="bottom">الرئيسيه</a></li>

<li><a href="documents.php?action=add_document_form" target="bottom">إضافة  وثيقة  </a></li>
<li><a href="documents.php?action=document_display" target="bottom" >الارشيف </a></li>
<li><a href="search_documents.php?action=search" target="bottom">البحث عن وثيقة </a></li>
<?php 
if ($part_no == 0 ) 
{ 
?>
<li><a href="users_home.php?action=users_display" target="bottom" >المستخدمين </a></li>
<li><a href="partments.php?action=partment_display" target="bottom">الأقسام</a></li>
<?php  }   ?> 
<li><a href="login.php?action=logout"  >تسجيل  الخروج </a></li>
</ul><!-- end -------first post-->



</div><!-----------end sidebar-------->




</td ></tr ></table> 
</div><!------end contant-------------->




<div id="footer" >

<div id="up-footer">
</div><!--end up-footer-->
<div id="down-footer">
<div class="copyright" align="center"> كل  الحقوق محفوظة  لطلاب  : <a href="#"</a> كلية  المجتمع _صنعاء </div>
</div><!--end down-footer-->

</div><!--end footer-->
</body>
</html>
