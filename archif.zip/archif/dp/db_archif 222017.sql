-- phpMyAdmin SQL Dump
-- version 2.11.5
-- http://www.phpmyadmin.net
--
-- المزود: localhost
-- أنشئ في: 02 فبراير 2017 الساعة 07:35
-- إصدارة المزود: 5.0.51
--  PHP إصدارة: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- قاعدة البيانات: `archif`
--

-- --------------------------------------------------------

--
-- بنية الجدول `documents`
--

CREATE TABLE IF NOT EXISTS `documents` (
  `doc_no` int(20) unsigned NOT NULL auto_increment,
  `doc_title` varchar(90) collate utf8_unicode_ci NOT NULL,
  `doc_info` varchar(300) collate utf8_unicode_ci NOT NULL,
  `file_no` varchar(60) collate utf8_unicode_ci NOT NULL,
  `part_no` int(11) NOT NULL,
  `doc_image` varchar(150) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`doc_no`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- إرجاع أو إستيراد بيانات الجدول `documents`
--

INSERT INTO `documents` (`doc_no`, `doc_title`, `doc_info`, `file_no`, `part_no`, `doc_image`) VALUES
(2, 'شهادة تخرج الطالب محمد الحمدي', 'هذه الوثيقة تحتوى  على شهادة لتخرج الطالب محمد أحمد يحي الحمدي', '10', 0, 'upload/document/s.png'),
(7, 'شيك', 'شيك بمبلغ 2000000 للمتعاقدين', '19', 6, 'upload/document/Sunset.jpg'),
(5, 'وثيقة بيع', 'وثيقة بيع جهاز نقدا للاخ محمد اليدومي', '65', 4, 'upload/document/logo3.png');

-- --------------------------------------------------------

--
-- بنية الجدول `partments`
--

CREATE TABLE IF NOT EXISTS `partments` (
  `part_no` int(20) unsigned NOT NULL auto_increment COMMENT 'رقم القسم',
  `part_name` varchar(80) collate utf8_unicode_ci NOT NULL COMMENT 'إسم  القسم',
  PRIMARY KEY  (`part_no`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- إرجاع أو إستيراد بيانات الجدول `partments`
--

INSERT INTO `partments` (`part_no`, `part_name`) VALUES
(3, 'شؤون  الطلاب'),
(4, 'شؤون  الأكادمية'),
(5, 'شؤون  الموظفين'),
(6, 'الشؤون  المالية والمحاسبية'),
(7, 'رئاسة الجامعة'),
(8, 'الشؤون رؤساء الأقسام');

-- --------------------------------------------------------

--
-- بنية الجدول `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(20) unsigned NOT NULL auto_increment,
  `ful_name` varchar(50) collate utf8_unicode_ci NOT NULL,
  `part_no` int(20) NOT NULL,
  `user_name` varchar(50) collate utf8_unicode_ci NOT NULL,
  `password` varchar(50) collate utf8_unicode_ci NOT NULL,
  `ch` int(2) NOT NULL,
  PRIMARY KEY  (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- إرجاع أو إستيراد بيانات الجدول `users`
--

INSERT INTO `users` (`user_id`, `ful_name`, `part_no`, `user_name`, `password`, `ch`) VALUES
(1, 'خيري السوادي ', 0, 'admin      ', 'admin', 1),
(3, 'أسامه لطفي', 4, '123', '321', 0),
(4, 'زكريا الوشلي', 0, 'abc', '123', 1),
(5, 'عبد  الكريم الوشلي', 6, 'abcd', 'abcd', 0);

-- --------------------------------------------------------

--
-- بنية الجدول `works`
--

CREATE TABLE IF NOT EXISTS `works` (
  `work_no` int(20) unsigned NOT NULL auto_increment,
  `user_id` int(20) NOT NULL,
  `work_type` varchar(50) collate utf8_unicode_ci NOT NULL,
  `doc_title` varchar(80) collate utf8_unicode_ci NOT NULL,
  `doc_info` varchar(200) collate utf8_unicode_ci NOT NULL,
  `file_no` varchar(50) collate utf8_unicode_ci NOT NULL,
  `part_no` int(30) NOT NULL,
  `doc_image` varchar(200) collate utf8_unicode_ci NOT NULL,
  `work_date` varchar(50) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`work_no`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- إرجاع أو إستيراد بيانات الجدول `works`
--

INSERT INTO `works` (`work_no`, `user_id`, `work_type`, `doc_title`, `doc_info`, `file_no`, `part_no`, `doc_image`, `work_date`) VALUES
(6, 1, 'حذف', 'بطاقة  شخصية', 'بطاقة شخصية للأخ  خيري السوادي', '12', 0, 'upload/delets/logo3.png', '02-02-2017 06:02');
