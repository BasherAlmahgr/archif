<?PHP
ob_start();
@session_start();


//التحقق من صحة الدخول للمستخدم
//echo $_SESSION["user_name"];
 If(!isset($_SESSION['user_name']) OR !isset($_COOKIE['user_name']))//التحقق ما إذا تم تسجيل الدخول أو  لا
 { 
exit("<META HTTP-EQUIV='refresh' CONTENT='0 URL=login.php'>");//الذهاب الي صفحة  تسجيل الدخول  مباشرتا أذا لم  يكن مسجلاً 
 }
 else
 {
 
 
 
$user_fullname=$_SESSION["user_name"];
$part_no=$_SESSION['part_no'];
$user_id=$_SESSION['user_id'];

include('include/1top.php');

//==================================================
	// استدعاء بيانات ملف اعداد الاتصال بقاعدة البيانات
	include('include/config.php');
	//==================================================
if(isset($_GET["action"])) $action=$_GET["action"] ; else  $action=" " ; 
 if(isset($_GET["sn"])) $doc_no=$_GET["sn"] ; 
  
if ($action=='document_display'  || $action== "document_delete")
{

if ($action== "document_delete")
{

//حفظ  عملية  الحذف في جدول المراقة  
$result = mysql_query("SELECT * FROM  documents WHERE
										 doc_no = $doc_no ") or die(mysql_error()); 	
										 
			$result_num = mysql_num_rows($result);
			if($result_num<>0)
			{
						$result_info       = mysql_fetch_array($result);
						$doc_no        = $result_info['doc_no'];
						$doc_title = $result_info['doc_title'];
						$doc_info = $result_info['doc_info' ];
						$file_no = $result_info['file_no' ];
						
						// نقل  الصورة  الى مجلد  المحذوفات 
						$doc_image = trim($result_info['doc_image' ]);
						if ( is_file($doc_image) )
						copy($doc_image, "upload/delets/" . basename($doc_image));
						echo "لقد تمت عملية  أرشفة  الصورة"; 
						
						//كود جلب   إسم  الصورة من  المسار  من أجل  تغير مكان  الملف 
						$doc_image_name=basename($doc_image);
						$doc_image="upload/delets/" . $doc_image_name ; 
						
						
							$work_date = date("d-m-Y H:i", time());
$query="INSERT INTO `works` (
`doc_title` ,
`file_no` ,
`doc_info` ,
`part_no` ,
`user_id` ,
`work_type` ,
`work_date` ,
`doc_image` 
)
VALUES (
 '$doc_title',
 '$file_no',
 '$doc_info' ,
 '$part_no' ,
'$user_id' ,
'حذف' ,
'$work_date' ,
 '$doc_image')";
$resq2=mysql_query($query);	
if  ($resq2) 
{
$mesnum=1; 
$message_text=" لقد تمت  عملية  الإضافة  الى  سجل  المتابعة <br><br>";
include('include/message.php');	
}
else
{
$mesnum=2; 
$message_text="لم تتم العملية بنجاح للرجوع الى الخلف <a href='javascript:history.back(1)'> إضغط هنا  </a> <br><br>";
include('include/message.php');				
}						

}
			

//إتمام عملية  الحذف 
//كود حذف الصورة السابقة
 if(isset($_GET["mm"])) $del_doc_image=trim($_GET['mm']);
if ( is_file($del_doc_image) )
if (unlink($del_doc_image))
echo "لقد تم حذف الصورة السابقة"; 

$query="DELETE FROM `documents` WHERE `doc_no` = '$doc_no'"  ;
$resq=mysql_query($query);
if ($resq==true)
{
$message_text="لقد تم حذف الوثيقة بنجاح <br><br>";
$mesnum=1; 
include('include/message.php');
echo "<META HTTP-EQUIV='refresh' CONTENT='2 URL=documents.php?action=document_display'> ";
}
else
{
$message_text= "لم تتم عملية حذف  الوثيقة... هناك مشكلة <br><br>";
$mesnum=2; 
include('include/message.php');
}
}




if ($part_no==0)
$query=("select *  from documents ORDER BY `doc_title` ASC ");
else
$query=("select *  from documents  where part_no=$part_no ORDER BY `doc_title` ASC ");


$resq=mysql_query($query);
$num_results = mysql_num_rows($resq);
if ($num_results==0)
{
echo  "  <br /> <br /><br /> <br /> لا  يوجد أي وثائق مخزنة  في قاعدة البيانات حالياً ...
<a href='documents.php?action=add_document_form'>للبدء في إضافة  وثيقة جديدة إضغط هنا </a>
"; 
}
else 
{
	

$i=0;
echo " <center>
<br><br>
 <div id='table-scroll'  style=' overflow:auto; '>
				<table id='rounded-corner' Profit' class='auto-style3' style=' height: 85px;  margin:0px auto; font:12pt PT Bold Heading, Geneva, sans-serif;' align='center' dir='ltr'>
<caption class='auto-styl' style='height: 40px; font-size: large; border: 5; border-color: #9845C8; background-color: #43001e; color: #FFFFFF' >
		الوثائق  المخزنة في  قواعد البيانات  
		</caption>   
   <thead>
    	<tr> 
			<th scope='col' class='rounded'  style='width: 10%'>  صورة  الوثيقة</th>
			<th scope='col' class='rounded'></th>
			<th scope='col' class='rounded'  style='width: 40%'>معلومات عن الوثيقة</th>
			 <th scope='col' class='rounded'  style='width: 30%'>عنوان الوثيقة</th>
			  <th scope='col' class='rounded'  style='width: 20%'>رقم  ملف الإرشيف</th>
            <th scope='col'>تعديل</th>
            <th scope='col' class='rounded-q4'>حذف</th>
        </tr>
    </thead>
        <tfoot>
    	<tr>
			<td class='rounded-foot-left' style='width: 10%'>&nbsp;</td>
        	<td colspan='7' class='rounded-foot-left'><em>
			<center><a href='documents.php?action=add_document_form'>إضافة   وثيقة جديدة </a></center></em></td>
        	
        </tr>
    </tfoot>
    <tbody> "; 
	
while($i<$num_results)
{
$row=mysql_fetch_array($resq);

	
    	echo "<tr>
        	<td style='width: 10%'><a href='image.php?im=$row[doc_image]' target='_blank'> 
			<image src='$row[doc_image]' title='$row[doc_title]' width='200px' height='140px' /> </a ><td>
			<td style='width: 40%'>$row[doc_info]</td>
            <td style='width: 30%'>$row[doc_title]</td>
			<td style='width: 200%'>$row[file_no]</td>
            <td><a href='documents.php?action=edit_document&sn=$row[doc_no]'>
			<img src='images/edit.png' alt='' title='تعديل' border='0' /></a></td>
           
		   <td> <a onClick=\"javascript: return confirm('هل أنت متأكد من حذف الوثيقة   /  $row[doc_title] ');\" href='documents.php?action=document_delete&sn=$row[doc_no]&mm=$row[doc_image]' class='ask'>
			<img src='images/del.gif' alt='' title='حذف' border='0' /></a></td>
        </tr>   ";
        $i++;
		}
      echo "  
    </tbody>
</table> 
</div></center>
";
}
}
else if ($action=="add_document_form")
{
echo "<br />
<form action='documents.php?action=add_document' method='post'  enctype='multipart/form-data'>
	<table align='center' cellpadding='10' cellspacing='10' class='auto-style3'  dir='rtl' style='width: 70%; text-align: center; border-color: #43001e ; color: #43001e;  margin:0px auto; font-size: large; font:12pt PT Bold Heading, Geneva, sans-serif;' >
		<caption  style='height: 40px; font-size: large; border: 5; border-color: #9845C8; background-color: #43001e; color: #FFFFFF' >
		الرجاء قم بإدخال البيانات المطلوبة لإضافة  وثيقة 
		</caption>
			<tr>
			<td style='width: 192px; height: 40px;'> رقم  ملف الإرشيف </td>
			<td style='height: 40px'> 
			<input name='file_no'  style='width: 400px; height: 40px; azimuth: center; border-style: solid; border-top-style: double; border-width: thick; border-color: #43001e; font-weight: bold; font-style: italic; font-size: large; text-align: center;  color: #43001e'>

			</td>
		</tr>
		<tr>
			<td style='width: 192px; height: 40px;'> عنوان الوثيقة </td>
			<td style='height: 40px'> 
			<input name='doc_title'  style='width: 400px; height: 40px; azimuth: center; border-style: solid; border-top-style: double; border-width: thick; border-color: #43001e; font-weight: bold; font-style: italic; font-size: large; text-align: center;  color: #43001e'>

			</td>
		</tr>
	
		<tr>
			<td style='width: 192px; height: 40px;'>معلومات عن الوثيقة </td>
			<td style='height: 40px'> 
			<input name='doc_info'  style='width: 400px; height: 40px; azimuth: center; border-style: solid; border-top-style: double; border-width: thick; border-color: #43001e; font-weight: bold; font-style: italic; font-size: large; text-align: center;  color: #43001e'> 

			</td>
		</tr>
			<tr>
			
			<td style='width: 192px; height: 40px;'> صورة  الوثيقة  </td>
			<td style='height: 40px'> 
	الرجاء قم بإختيار صورة من أجل إتمام الإضافة	 <br />
			<input type='file' name='doc_image' id='realupload2'  style='width: 300px; border-color: #43001e; height: 40px; background-color: #43001e; color: #FFFFFF; font-size: large'>
			 	<br></td>
		</tr>
		<tr>
			<td colspan='2'>
			<input dir='rtl' name='Submit' style='width: 159px; border-color: #43001e; height: 40px; background-color: #43001e; color: #FFFFFF; font-size: large;' type='submit' value='إضــــــافة' />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<input dir='rtl' name='Reset1' style='width: 125px; height: 40px; border-color: #43001e; color: #FFFFFF; background-color: #43001e; font-size: large;' type='reset' value='مسح البيانات' /></td>
		</tr>
	</table>
</form>


     
";

}

else if ($action=="update_document" || $action=="add_document")
{
if($_POST['Submit']) {

$doc_title=trim($_POST["doc_title"]);
$doc_info=$_POST["doc_info"]; 
$file_no=$_POST["file_no"]; 

//كود جلب إسم الصورة وإرسالها الى الدالة من أجل رفعها الى المجلد المطلوب
$doc_image=$_FILES['doc_image']['name'] ;
$tmpdoc_image=$_FILES['doc_image']['tmp_name'] ;

// التاكد من تسجيله لبقية البيانات الضروريه 
$error_count =0;
			if($doc_title =="")
			{
				$error_count ++;
				$error_info .= "- لم تدخل عنوان الوثيقة <br><br>";
			}
			if($doc_info =="")
			{
				$error_count ++;
				$error_info .= "- لم تدخل أي معلومات تخص الوثيقة <br><br>";
			}
			if($file_no =="")
			{
				$error_count ++;
				$error_info .= "- لم تقم بإدخال رقم ملف الأرشفة الخاص  بالوثيقة <br><br>";
			}
			
			if($doc_image ==""  || $tmpdoc_image=="" )
			{
				$error_count ++;
				$error_info .= "- لم تقوم  بعمل  صورة للوثيقة <br><br>";
			}
			if($error_count<>0)
			{
			$mesnum=2; 
			$message_text="<center><p dir='rtl'>لم تتم العمليه لأنه يوجد لديك عدد $error_count خطأ/أخطاء وهي : </p></center><br><br>";
			include('include/message.php');
				
				echo "<p dir='rtl'>$error_info</p>";
				
				echo "<br><br><p align='center'><a href='javascript:history.back(1)'>اضغط هنا للمحاوله مره اخرى</a></p>";
			
			}
			else 
			{
			
			

//كود حذف الصورة السابقة
  if(isset($_GET["mm"]))
  {	  $del_doc_image=trim($_GET['mm']);
if ( is_file($del_doc_image) )
if (unlink($del_doc_image))
echo "لقد تم حذف  صورة الوثيقة   السابقة بنجاح <br />"; 
  } 
  
include('include/upload_image.php');
$path ='upload/document/';   //كود مسار الصورة التي سيتم الرفع اليه
$doc_image=trim(upload($doc_image,$tmpdoc_image,$path));

 

 
if ($action=="update_document")
{  
//echo "$student_num + $student_num";
$query="UPDATE `documents` SET 
`doc_title` = '$doc_title',
`file_no` = '$file_no' ,
`doc_info` = '$doc_info' ,
`doc_image`= '$doc_image' 
WHERE  `doc_no` = '$doc_no'" ;
$resq=mysql_query($query);
 /*
 $work_date = date("d-m-Y H:i", time());
$query="INSERT INTO `works` (
`doc_title` ,
`file_no` ,
`doc_info` ,
`part_no` ,
`user_id` ,
`work_type` ,
`work_date` ,
`doc_image` 
)
VALUES (
 '$doc_title',
 '$file_no',
 '$doc_info' ,
 '$part_no' ,
'$user_id' ,
'تعديل' ,
'$work_date' ,
 '$doc_image')";
$resq2=mysql_query($query);
*/
$message_text="لقد تمت عملية التعديل بنجاح  <br><br>";
echo "<META HTTP-EQUIV='refresh' CONTENT='2 URL=documents.php?action=document_display'> ";

}
else
{

 
 
 
$query="INSERT INTO `documents` (
`doc_title` ,
`file_no` ,
`doc_info` ,
`part_no` ,
`doc_image` 
)
VALUES (
 '$doc_title',
 '$file_no',
 '$doc_info' ,
  '$part_no' ,
 '$doc_image')";
$resq=mysql_query($query);

$message_text="لقد تم إضافة   الوثيقة   $doc_title الى قاعدة البيانات  بنجاح   <br><br>";
echo "<META HTTP-EQUIV='refresh' CONTENT='2 URL=documents.php?action=document_display'> ";
}
if ($resq === true) 
{$mesnum=1; 
include('include/message.php');
 }
else
{$mesnum=2; 
$message_text="لم تتم العملية بنجاح للرجوع الى الخلف <a href='javascript:history.back(1)'> إضغط هنا  </a> <br><br>";
include('include/message.php');
 }
 }
 }
 
else
echo "لم تقم بالضغط على زر  الحفظ .. للرجوع الى الخلف إضغط هنا <a href='javascript:history.back(1)'> إضغط هنا  </a> <br><br>" ;

}

else if ($action=="edit_document")
{
$query=("SELECT * FROM documents  WHERE doc_no = $doc_no");
$resq=mysql_query($query);

$num_results = mysql_num_rows($resq)  or die ("لا توجد   وثائق مخزنة في  قاعدة  البيانات   ");
$i=0;
while($i<$num_results)
{
$row=mysql_fetch_array($resq);
 
		
echo "<br />
<form action='documents.php?action=update_document&sn=$row[doc_no]&mm=$row[doc_image]' method='post'  enctype='multipart/form-data'>
	<table align='center' cellpadding='10' cellspacing='10' class='auto-style3'  dir='rtl' style='width: 70%; text-align: center; border-color: #43001e ; color: #43001e; margin:0px auto; font:12pt PT Bold Heading, Geneva, sans-serif; font-size: large' >
		<caption  style='height: 40px; font-size: large; border: 5; border-color: #9845C8; background-color: #43001e; color: #FFFFFF' >
		الرجاء قم بإدخال البيانات المطلوبة لإتمام عملية التعديل
		</caption>
		<tr>
			<td style='width: 192px; height: 20px;'> </td>
			<td style='height: 20px'>
			</td>
		</tr>
		<tr>
			<td style='width: 192px; height: 40px;'> رقم  ملف الإرشيف </td>
			<td style='height: 40px'> 
			<input name='file_no' value = '$row[file_no]'   style='width: 400px; height: 40px; azimuth: center; border-style: solid; border-top-style: double; border-width: thick; border-color: #43001e; font-weight: bold; font-style: italic; font-size: large; text-align: center;  color: #43001e'>

			</td>
		</tr>
		<tr>
			<td style='width: 192px; height: 40px;'>إسم  الوثيقة</td>
			<td style='height: 40px'> 
			<input name='doc_title'  value = '$row[doc_title]'  style='width: 400px; height: 40px; azimuth: center; border-style: solid; border-top-style: double; border-width: thick; border-color: #43001e; font-weight: bold; font-style: italic; font-size: large; text-align: center;  color: #43001e'>

			</td>
		</tr>
		<tr>
			<td style='width: 192px; height: 40px;'>معلومات عن  الوثيقة </td>
			<td style='height: 40px'> 
			<input name='doc_info'  value = '$row[doc_info]' style='width: 400px; height: 40px; azimuth: center; border-style: solid; border-top-style: double; border-width: thick; border-color: #43001e; font-weight: bold; font-style: italic; font-size: large; text-align: center;  color: #43001e'> 

			</td>
		</tr>
			<tr>
			
			<td style='width: 192px; height: 40px;'>صورة   الوثيقة</td>
			<td style='height: 40px'> 
	الرجاء قم بإختيار صورة من أجل إتمام التعديل	 <br />
			<input type='file' name='doc_image' id='realupload2'  style='width: 300px; border-color: #43001e; height: 40px; background-color: #43001e; color: #FFFFFF; font-size: large'>
			 	<br><br><br><br></td>
		</tr>
		<tr>
			<td colspan='2'>
			<input dir='rtl' name='Submit' style='width: 159px; border-color: #43001e; height: 40px; background-color: #43001e; color: #FFFFFF; font-size: large;' type='submit' value='تعــــديـــل' />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<input dir='rtl' name='Reset1' style='width: 125px; height: 40px; border-color: #43001e; color: #FFFFFF; background-color: #43001e; font-size: large;' type='reset' value='مسح البيانات' /></td>
		</tr>
	</table>
</form>

<br><br><br>
     
";
$i++;
}
}

else 
{

//الإنتقال الى لوحة التحكم الرئيسية 
 echo "<META HTTP-EQUIV='refresh' CONTENT='0 URL=main.php'> ";
	
}

}
?>
