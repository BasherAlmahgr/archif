<?php  
include('include/1top.php');
$doc_image=$_GET[im];
echo  "<center> <image src='$doc_image' title='هذه هي الصورة الأصلية  بالحجم الأصلي ' /> ";
?>
