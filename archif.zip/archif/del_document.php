<?PHP
ob_start();
@session_start();


//التحقق من صحة الدخول للمستخدم
//echo $_SESSION["user_name"];
 If(!isset($_SESSION['user_name']) OR !isset($_COOKIE['user_name']))//التحقق ما إذا تم تسجيل الدخول أو  لا
 { 
exit("<META HTTP-EQUIV='refresh' CONTENT='0 URL=login.php'>");//الذهاب الي صفحة  تسجيل الدخول  مباشرتا أذا لم  يكن مسجلاً 
 }
 else
 {
 
 
 
$user_fullname=$_SESSION["user_name"];
$part_no=$_SESSION['part_no'];
$user_id=$_SESSION['user_id'];

include('include/1top.php');

//==================================================
	// استدعاء بيانات ملف اعداد الاتصال بقاعدة البيانات
	include('include/config.php');
	//==================================================

	if(isset($_GET["action"])) $action=$_GET["action"] ; else  $action=" " ; 
 if(isset($_GET["sn"])) $work_no=$_GET["sn"] ; 
   
if ($action=='document_display'  || $action== "document_delete")
{

if ($action== "document_delete")
{			

//إتمام عملية  الحذف 
//كود حذف الصورة السابقة
 if(isset($_GET["mm"]))
  {	
$del_doc_image=trim($_GET['mm']);
if ( is_file($del_doc_image) )
if (unlink($del_doc_image))
echo "لقد تم حذف الصورة السابقة"; 
  }

$query="DELETE FROM `works` WHERE `work_no` = '$work_no'"  ;
$resq=mysql_query($query);
if ($resq==true)
{
$message_text="لقد تم حذف الوثيقة بنجاح <br><br>";
$mesnum=1; 
include('include/message.php');
echo "<META HTTP-EQUIV='refresh' CONTENT='2 URL=del_document.php?action=document_display'> ";
}
else
{
$message_text= "لم تتم عملية حذف  الوثيقة... هناك مشكلة <br><br>";
$mesnum=2; 
include('include/message.php');
}
}





$query=("select *  from works ORDER BY `doc_title` ASC ");


$resq=mysql_query($query);
$num_results = mysql_num_rows($resq);
if ($num_results==0)
{
echo  "  <br /> <br /><br /> <br /> لا  يوجد أي وثيقة قد تم حذفها في قاعدة  البيانات...
"; 
}
else 
{
	

$i=0;
echo " <center>
<br><br>
 <div id='table-scroll'  style=' overflow:auto; '>
				<table id='rounded-corner' Profit' class='auto-style3' style=' height: 85px;  margin:0px auto; font:12pt PT Bold Heading, Geneva, sans-serif;' align='center' dir='ltr'>
<caption class='auto-styl' style='height: 40px; font-size: large; border: 5; border-color: #9845C8; background-color: #43001e; color: #FFFFFF' >
		الوثائق  التي تم حذفها  من قواعد البيانات  
		</caption>   
   <thead>
    	<tr> 
			<th scope='col' class='rounded'  style='width: 10%'>  صورة  الوثيقة</th>
			<th scope='col' class='rounded'></th>
			<th scope='col' class='rounded'  style='width: 30%'>معلومات عن الوثيقة</th>
			 <th scope='col' class='rounded'  style='width: 20%'>عنوان الوثيقة</th>
			  <th scope='col' class='rounded'  style='width: 20%'>رقم  ملف الإرشيف</th>
            <th scope='col' class='rounded'  style='width: 40%'>إسم  الستخدم الذي حذف </th>
            <th scope='col' class='rounded-q4'>حذف</th>
        </tr>
    </thead>
      
    <tbody> "; 
	
while($i<$num_results)
{
$row=mysql_fetch_array($resq);

	
    	echo "<tr>
        	<td style='width: 10%'><a href='image.php?im=$row[doc_image]' target='_blank'> 
			<image src='$row[doc_image]' title='$row[doc_title]' width='200px' height='140px' /> </a ><td>
			<td style='width: 30%'>$row[doc_info]</td>
            <td style='width: 20%'>$row[doc_title]</td>
			<td style='width: 20%'>$row[file_no]</td>
            <td style='width: 40%'>";
			
				//تعبئة  إسم المستخدم
			$query=("select ful_name  from users where part_no= $row[part_no]");
            $resq2=mysql_query($query);
            if (  $resq2 >0)
			{
			 $row2=mysql_fetch_array($resq2);
			 echo "$row2[ful_name]  ";
			}
			echo "</td>
           
		   <td> <a onClick=\"javascript: return confirm('هل أنت متأكد من إتمام  عملية  الحذف لــ   /  $row[doc_title] ');\" href='del_document.php?action=document_delete&sn=$row[work_no]&mm=$row[doc_image]' class='ask'>
			<img src='images/del.gif' alt='' title='حذف' border='0' /></a></td>
        </tr>   ";
        $i++;
		}
      echo "  
    </tbody>
</table> 
</div></center>
";
}
}

else 
{

//الإنتقال الى لوحة التحكم الرئيسية 
 echo "<META HTTP-EQUIV='refresh' CONTENT='0 URL=main.php'> ";
	
}

}
?>
